<?php

	/*
	* 
	* David Lettier (C) 2013.
	* 
	* http://www.lettier.com/
	* 
	*/
	
	require( '/virtual/users/e14157-14235/storage/vars.php' );
	
	$link = mysql_connect( "localhost", $c, $d ) or die( mysql_error( ) );
	
	$average_fitness = floatval( mysql_real_escape_string( $_POST[ 'average_fitness' ] ) );
	
	$population_size = intval( mysql_real_escape_string( $_POST[ 'population_size' ] ) );
	
	$number_of_parameters = intval( mysql_real_escape_string( $_POST[ 'number_of_parameters' ] ) ); 
	
	$parameters = mysql_real_escape_string( $_POST[ 'parameters' ] ); 	
	
	mysql_select_db( "lettier0" ) or die( mysql_error( ) );
	
	$row_sql = mysql_query( "SELECT MAX( `average_fitness` ) AS max FROM `simpl_genomes` WHERE `population_size` = '$population_size';" );
	$row = mysql_fetch_array( $row_sql );
	$largest_fitness_average = floatval( $row[ 'max' ] );
	
	$result = null;
	
	if ( $largest_fitness_average != 0.0 OR !is_null( $largest_fitness_average ) OR !empty( $largest_fitness_average ) )
	{
	
		if ( $average_fitness > $largest_fitness_average )
		{
			
			$result = mysql_query( "INSERT INTO `lettier0`.`simpl_genomes` ( `id`, `entry_date`, `average_fitness`, `population_size`, `number_of_parameters`, `parameters` ) VALUES ( NULL, CURRENT_TIMESTAMP, $average_fitness, $population_size, $number_of_parameters, '$parameters' );" ); 
			
			if ( $result )
			{
				
				echo "[Store_Genomes] Added genome parameters successfully.";
				
			}
			else
			{
				
				echo mysql_error( $link );
				
			}
		}
		else
		{
		
			echo "[Store_Genomes] Need average fitness higher than $largest_fitness_average.";
			
		}
	}
	else
	{
	
		$result = mysql_query( "INSERT INTO `lettier0`.`simpl_genomes` ( `id`, `entry_date`, `average_fitness`, `population_size`, `number_of_parameters`, `parameters` ) VALUES ( NULL, CURRENT_TIMESTAMP, '$average_fitness', '$population_size', '$number_of_parameters', '$parameters' );" ); 
			
		if ( $result )
		{
			
			echo "[Store_Genomes] Added genome parameters successfully.";
			
		}
		else
		{
			
			echo mysql_error( $link );
			
		}
	
	}

?>