/*
 * 
 * David Lettier (C) 2013.
 * 
 * http://www.lettier.com/
 * 
 * Simple Pong Learner or SimPL.
 * 
 * Single sided pong clone with only one paddle which learns to follow and collide with the ball.
 * 
 */


var take_control = false;
var pause        = false;
var show_debug   = false;
var stop_tournament = false;

var top_wall    = new Static_Object( "top_wall"    );
var right_wall  = new Static_Object( "right_wall"  );
var bottom_wall = new Static_Object( "bottom_wall" );
var left_wall   = new Static_Object( "left_wall"   );

var random_angle_range = { min: 135, max: 225 };
var random_angle = random_angle_range.min + ( random_angle_range.max - random_angle_range.min ) * Math.random( );

var starting_ball_magnitude = 1000;
var starting_paddle_magnitude = 1000;
var starting_paddle_angle = 90;

var ball   = new Physics_Object(  new Dynamic_Object( "ball" ),  random_angle,          starting_ball_magnitude   );
var paddle = new Physics_Object( new Dynamic_Object( "paddle" ), starting_paddle_angle, starting_paddle_magnitude );

var physics_engine = new Physics_Engine( collision_handler, paddle, ball, top_wall, right_wall, bottom_wall, left_wall );

var fps_monitor = new FPS_Monitor( );

var debug_manager = new Debug_Manager( "debug" );

var database_manager = new Database_Manager( );

var learner_parameters = {
			
	inputs:  4,
	outputs: 1,
	number_of_hidden_layers:  1,
	neurons_per_hidden_layer: 3,
	bias: -1,
	activation_response: 1,
	population_size:  10,
	crossover_rate:   0.7,
	mutation_rate:    0.1,
	max_perturbation: 0.3,
	number_of_elite:        4,
	number_of_elite_copies: 1,
	fitness_credit_for_tracking: .1,	
	fitness_for_hitting_paddle: 1
	
};

var learner = {
	
	neural_net: null,
	neural_net_output: null,
	neural_network_weights: null,
	evaluation_start_time: 0,
	evaluation_end_time:   0,
	evalutation_times: new Array( ),
	evaluation_time_averages: new Array( ),
	neural_network_round: 0,
	evaluate_current_neural_network: false,
	current_neural_net_in_evalutation: 0
	
};

learner.neural_net = new Neural_Net( learner_parameters.inputs, learner_parameters.outputs, learner_parameters.number_of_hidden_layers, learner_parameters.neurons_per_hidden_layer, learner_parameters.bias, learner_parameters.activation_response );
//learner.genetic_algorithm = new Genetic_Algorithm( learner_parameters.population_size, learner.neural_net.get_number_of_weights( ), learner_parameters.crossover_rate, learner_parameters.mutation_rate, learner_parameters.max_perturbation, learner_parameters.number_of_elite, learner_parameters.number_of_elite_copies );
//learner.current_genetic_algorithm_population = learner.genetic_algorithm.get_population( );

learner.neural_network_weights = new Array( );

nn_params_1 = [-0.05759830633178353,0.34026416479609906,0.9696962656453252,-0.7338683442212641,-0.24583435570821166,-0.6132481233216822,0.8165654454845934,-0.6154058407992125,0.2340331629384309,-0.8898248174227774,0.8422164251096547,-0.08250228371471163,-0.4805793082341552,0.46870551258325577,-0.7377757259178906,0.231303789652884,-0.3258746772073209,-0.7423356920480728,-0.6992612038739026];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [-0.05759830633178353,0.6068922734819353,0.5990837957710027,-0.8359575997106731,-0.24583435570821166,-0.6132481233216822,0.8019698384217917,-0.8276106251869351,-0.08368525709956884,-0.8898248174227774,1,0.16881896383129064,0.019046403840184245,0.40197124481201174,-0.9202141295652836,0.1188164172694087,-0.5353201171383262,-0.7423356920480728,-0.7186529730912298];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [-0.052311890432611106,0.6068922734819353,0.43772233137860883,-0.8359575997106731,-0.07746032946743073,-0.3909963170532137,0.553252780996263,-0.8276106251869351,-0.08368525709956884,-0.7155043432954699,1,0.16881896383129064,0.019046403840184245,0.40197124481201174,-1,0.1188164172694087,-0.3784782327711582,-0.7423356920480728,-0.7186529730912298];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [0.08532063378952442,0.6068922734819353,0.49547388479113563,-0.7827904053032398,-0.13037031330168253,-0.6666085239499807,0.7188383534085004,-0.9656285902485251,-0.1143609395250678,-0.9825015645939856,0.9497075759805739,0.16881896383129064,0.11127894506789746,0.4693231076933444,-1,0.1188164172694087,-0.139538910984993,-0.7423356920480728,-0.9327614789362997];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [0.08532063378952442,0.45116196093149485,0.22529990333132435,-0.8359575997106731,-0.36632762062363333,-0.6666085239499807,0.6950761773157863,-0.8292680899612606,-0.1143609395250678,-0.9825015645939856,0.9032646583393216,0.16881896383129064,0.09845839850604536,0.1828085971996189,-0.9068871044088155,0.4789387509226799,-0.139538910984993,-0.9766018086113035,-0.6824077892582863];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [ 0.08532063378952442,0.2374649829231203,0.13620262346230438,-0.5921985007356853,-0.36632762062363333,-0.7906107807066292,0.40944352224469166,-0.8222892524208874,0.054606627020984885,-0.9825015645939856,0.7725353565532713,0.19242138881236318,0.09845839850604536,0.1828085971996189,-0.9068871044088155,0.4789387509226799,-0.139538910984993,-1,-0.6041929948143661 ];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [ 0.08532063378952442,0.08348891595378521,0.13620262346230438,-0.37817829055711627,-0.5096419071778655,-0.7906107807066292,0.40944352224469166,-0.8222892524208874,0.054606627020984885,-0.9825015645939856,0.7725353565532713,0.19242138881236318,0.34200365375727415,0.47407328211702415,-0.8748401201330125,0.4789387509226799,-0.23504983414895833,-1,-0.6041929948143661 ];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [ 0.5204852689523249,0.4170253929216415,-0.028491303464397877,-0.09477964150719348,-0.2996531295124441,-0.5421629836782813,0.4329122219234703,-0.8286082794889807,0.054606627020984885,-1,0.7725353565532713,0.2896611444652081,0.34200365375727415,0.3881853202357889,-0.8748401201330125,0.4789387509226799,-0.23504983414895833,-1,-0.5140682155732065 ];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [ 0.5204852689523249,0.48585311002098025,-0.028491303464397877,-0.09477964150719348,-0.2996531295124441,-0.5421629836782813,0.4329122219234703,-0.8922357806004584,0.2892071426846087,-0.7765874616336078,0.6651210385840385,0.03806942296214405,0.34200365375727415,0.056114586675539695,-0.6336737101897597,0.4789387509226799,0.05008252412080763,-1,-0.5140682155732065 ];

learner.neural_network_weights.push( nn_params_1 );

nn_params_1 = [ 0.5204852689523249,0.48585311002098025,-0.028491303464397877,-0.09477964150719348,-0.6171158207580447,-0.5150350311771035,0.27637765011750137,-0.8286082794889807,0.054606627020984885,-1,0.9451253911014645,0.2095114742871374,0.34200365375727415,0.3881853202357889,-1,0.5460114746354521,-0.45893217916600404,-1,-0.5140682155732065 ];

learner.neural_network_weights.push( nn_params_1 );

learner.neural_net.put_weights( learner.neural_network_weights[ 0 ] );

learner.current_neural_net_in_evalutation = 0;

learner.neural_network_round = 1;

learner.neural_net_output = 0;

/*

database_manager.send_and_receive( "assets/scripts/retrieve_genomes.php", "population_size=" + learner_parameters.population_size + "&number_of_parameters=" + learner.genetic_algorithm.chromosome_length, database_manager, "initial_top_population", false );

var top_database_population_parameters = database_manager.responses[ "initial_top_population" ];

if ( top_database_population_parameters != "" )
{
	
	top_database_population_parameters = top_database_population_parameters.split( "," );
	
	for ( var i = 0; i < top_database_population_parameters.length; ++i )
	{
		
		top_database_population_parameters[ i ] = parseFloat( top_database_population_parameters[ i ] );
		
	}
	
	var top_population = learner.genetic_algorithm.replace_population_parameters( top_database_population_parameters );
	
	learner.neural_net.put_weights( top_population[ 0 ].weights );
	
}

*/

var ball_style = window.getComputedStyle( ball.dynamic_object.object, null);
var ball_style_transform =  	ball_style.getPropertyValue( "-webkit-transform" ) ||
						ball_style.getPropertyValue( "-moz-transform"    ) ||
						ball_style.getPropertyValue( "-ms-transform"     ) ||
						ball_style.getPropertyValue( "-o-transform"      ) ||
						ball_style.getPropertyValue( "transform"         );
var ball_div_transform_angle    = 360;
var ball_div_transform_angle_by = 20;

function draw( time_stamp ) 
{
	
	var time_delta = fps_monitor.get_time_delta( time_stamp );
	
	if ( !pause )
	{
	
		if ( !stop_tournament )
		{
		
			debug_manager.add_or_update( "FPS", fps_monitor.get_fps( time_stamp ) );
		
			debug_manager.add_or_update( "Paddle", paddle );
			
			debug_manager.add_or_update( "Ball", ball );
		
			handle_neural_network_ouput( );
			
			//debug_manager.add_or_update( "Current Genome", learner.current_genome_in_evalutation );

			debug_manager.add_or_update( "NN", learner.neural_net );
			
			debug_manager.add_or_update( "NN Weights", learner.neural_net.get_weights( ) );
			
			//debug_manager.add_or_update( "GA", learner.genetic_algorithm );
		
			physics_engine.update( time_delta );
			
			// Spin the ball div to give the illusion of flying through the air.
									
			if ( ball_style_transform != undefined && ball.get_magnitude( ) != 0 )
			{
			
				ball.dynamic_object.object.style.webkitTransform = "rotate(" + ball_div_transform_angle + "deg)";
				ball.dynamic_object.object.style.MozTransform    = "rotate(" + ball_div_transform_angle + "deg)";
				ball.dynamic_object.object.style.msTransform     = "rotate(" + ball_div_transform_angle + "deg)";
				ball.dynamic_object.object.style.OTransform      = "rotate(" + ball_div_transform_angle + "deg)";
				ball.dynamic_object.object.style.transform       = "rotate(" + ball_div_transform_angle + "deg)";
				
				if ( ball.get_angle( ) >= 90 && ball.get_angle( ) <= 270 )
				{
				
					// Spin counter clock-wise if it is going towards the left of the screen.
					
					ball_div_transform_angle = ball_div_transform_angle < 0 ? 360 : ball_div_transform_angle - ( ball_div_transform_angle_by * ( ball.get_magnitude( ) / starting_ball_magnitude ) );
					
				}
				else
				{
					
					ball_div_transform_angle = ball_div_transform_angle > 360 ? 0 : ball_div_transform_angle + ( ball_div_transform_angle_by * ( ball.get_magnitude( ) / starting_ball_magnitude ) );
					
				}
				
			}
			
			// Time to evaluate the current neural network?
			
			if ( learner.evaluate_current_neural_network )
			{
				
				handle_neural_network_evaluation( );
				
			}
		
			debug_manager.print( );
		
		}
		
	}
	
	request_animation_id = window.requestAnimationFrame( draw );
	
}

// The following stub was taken from https://gist.github.com/paulirish/1579671.
			
( function ( ) 
{
	var lastTime = 0;
	var vendors = ['ms', 'moz', 'webkit', 'o'];
	for( var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x ) 
	{
		
		window.requestAnimationFrame = window[ vendors[ x ] + 'RequestAnimationFrame' ];
		window.cancelAnimationFrame = window[vendors[x]+'CancelAnimationFrame'] || window[ vendors[ x ]+'CancelRequestAnimationFrame' ];
		
	}

	if ( !window.requestAnimationFrame )
	{
		
		window.requestAnimationFrame = function ( callback, element ) 
		{
			
			var currTime = new Date( ).getTime( );
			var timeToCall = Math.max( 0, 16 - ( currTime - lastTime ) );
			var id = window.setTimeout( function ( ) { callback( currTime + timeToCall ); }, timeToCall );
			lastTime = currTime + timeToCall;
			return id;
			
		};
		
	}

	if ( !window.cancelAnimationFrame )
	{
		
		window.cancelAnimationFrame = function ( id ) 
		{
			
			clearTimeout( id );
			
		};
	
	}
} ( ) );

var request_animation_id = window.requestAnimationFrame( draw );

function reset( )
{
	
	random_angle = random_angle_range.min + ( random_angle_range.max - random_angle_range.min ) * Math.random( );	
	ball.dynamic_object.set_center( document.getElementById( "ball_slot" ).offsetLeft, document.getElementById( "ball_slot" ).offsetTop );
	ball.set_magnitude( starting_ball_magnitude );
	ball.set_angle( random_angle );
	
	paddle.dynamic_object.set_center( document.getElementById( "paddle_slot" ).offsetLeft, document.getElementById( "paddle_slot" ).offsetTop );
	paddle.set_magnitude( starting_ball_magnitude );
	paddle.set_angle( starting_paddle_angle );

	take_control = false;	
	pause = false;
	
}

document.onkeyup = handle_key;

function handle_key( kevent )
{
	var key = ( window.event ) ? event.keyCode : kevent.keyCode;
	
	switch ( key )
	{
	
		case 68: // [d] key.
			
			show_debug = !show_debug
			
			if ( show_debug ) debug_manager.show_debug( );
			else debug_manager.hide_debug( );
			
			break;
			
		case 70: // [f] key.
			
			debug_div = document.getElementById( "debug" );
			
			debug_div_font_size = parseInt( window.getComputedStyle( debug_div, null).getPropertyValue( 'font-size' ), 10 );
			
			if ( window.event.shiftKey )
			{
				
				debug_div_font_size -= 1;
				
				debug_div.style.fontSize = debug_div_font_size + "px";
				
			}	
			else
			{
				
				debug_div_font_size += 1;
				
				debug_div.style.fontSize = debug_div_font_size + "px";
				
			}
			
			break;
		
		case 77: // [m] key.
			
			ball.set_magnitude( ball.get_magnitude( ) + 100 );						
			
			break;		
		
		case 80: // [p] key.
			
			pause = !pause;						
			
			break;
			
		case 82: // [r] key.
			
			reset( );
			
			break;
			
		case 84: // [t] key.
			
			take_control = !take_control;						
			
			break;
			
	}
}

document.onmousemove = handle_mouse_move;

function handle_mouse_move( mevent )
{
	
	if ( !take_control ) return null;
	
	mevent = ( window.event ) ? window.event : mevent;
	
	if ( ( mevent.clientY - ( paddle.dynamic_object.get_height( ) / 2 ) ) >= ( window.innerHeight - paddle.dynamic_object.get_height( ) ) ) 
	{ 
		
		paddle.dynamic_object.set_center( paddle.dynamic_object.get_left( ), window.innerHeight - paddle.dynamic_object.get_height( ) );
		
		return null;
		
	}
	else if ( ( mevent.clientY - ( paddle.dynamic_object.get_height( ) / 2 ) ) <= 0 )
	{ 
		
		paddle.dynamic_object.set_center( paddle.dynamic_object.get_left( ), 0 );
		
		return null;
		
	}
	
	paddle.dynamic_object.set_center( paddle.dynamic_object.get_left( ), mevent.clientY - ( paddle.dynamic_object.get_height( ) / 2 ) );
	
}

function handle_neural_network_ouput( )
{
	
	if ( take_control ) 
	{
		
		paddle.set_magnitude( 0 );
		
		paddle.set_angle( starting_paddle_angle );
		
		return null;
		
	}
	
	var dist_to_ball_y    = paddle.dynamic_object.get_distance_to( ball.dynamic_object ).y;
	var ball_velocity     = ball.get_velocity( );
	var paddle_y_location = paddle.dynamic_object.get_center( ).y;
	
	learner.neural_net_output = learner.neural_net.update( [ dist_to_ball_y, ball_velocity.x, ball_velocity.y, paddle_y_location ] );
	
	debug_manager.add_or_update( "NN Input", dist_to_ball_y + " " + ball_velocity.x + " " + ball_velocity.y + " " + paddle_y_location );
	
	// learner.current_genome_tracking.push( dist_to_ball_y );
	
	debug_manager.add_or_update( "NN Output", learner.neural_net_output );
	
	if ( learner.neural_net_output < 0.0 )
	{
		
		paddle.set_magnitude( starting_paddle_magnitude * ( -1 * learner.neural_net_output ) );
		
		paddle.set_angle( 270 );
		
	}
	else if ( learner.neural_net_output == 0.0 )
	{
		
		paddle.set_magnitude( 0 );
		
		paddle.set_angle( starting_paddle_angle );
		
	}
	else if ( learner.neural_net_output > 0.0 )
	{
		
		paddle.set_magnitude( starting_paddle_magnitude * learner.neural_net_output );
		
		paddle.set_angle( 90.0 );
		
	}
	
}

function handle_neural_network_evaluation( )
{	
	
	/*
	
	if ( learner.current_genome_tracking.length % 2 == 0 ) // Even.
	{
	
		j = learner.current_genome_tracking.length / 2;
		
		// Go through tracking points and compare in pairs.
		// (0<=>1), (2<=>3), ..., (n-2<=>n-1)
		
		do
		{
			
			if ( learner.current_genome_tracking[ i ] == 0.0 && learner.current_genome_tracking[ i + 1 ] == 0.0 ) // On point.
			{
				
				fitness += learner_parameters.fitness_credit_for_tracking;
				
			}
			else if ( learner.current_genome_tracking[ i ] > learner.current_genome_tracking[ i + 1 ] ) // Following.
			{
				
				fitness += learner_parameters.fitness_credit_for_tracking;
				
			}				
			else if ( learner.current_genome_tracking[ i ] < learner.current_genome_tracking[ i + 1 ] ) // Going away from.
			{
				
				fitness -= learner_parameters.fitness_credit_for_tracking;
				
			}
			else if ( learner.current_genome_tracking[ i ] == learner.current_genome_tracking[ i + 1 ] ) // Staying put.
			{
				
				fitness += 0;
				
			}
			
			i += 2;
			
		}
		while ( j-- )
	}		
	else // Odd.
	{
		
		j = ( learner.current_genome_tracking.length - 1 ) / 2; // Minus one to make it even.
		
		// Go through tracking points and compare in pairs.
		// (0<=>1), (2<=>3), ..., (n-2<=>n-1)
		
		do
		{
			
			if ( learner.current_genome_tracking[ i ] == 0.0 && learner.current_genome_tracking[ i + 1 ] == 0.0 ) // On target.
			{
				
				fitness += learner_parameters.fitness_credit_for_tracking;
				
			}
			else if ( learner.current_genome_tracking[ i ] > learner.current_genome_tracking[ i + 1 ] ) // Going toward.
			{
				
				fitness += learner_parameters.fitness_credit_for_tracking;
				
			}				
			else if ( learner.current_genome_tracking[ i ] < learner.current_genome_tracking[ i + 1 ] ) // Going away.
			{
				
				fitness -= learner_parameters.fitness_credit_for_tracking;
				
			}
			else if ( learner.current_genome_tracking[ i ] == learner.current_genome_tracking[ i + 1 ] ) // Didn't move at all.
			{
				
				fitness += 0;
				
			}
			
			i += 2;
			
		}
		while ( j-- )
			
	}
	
	learner.current_genome_tracking = [ ];

	*/
	
	pause = true;
	
	var i = 0;
	var j = 0;
	var k = 0;
	
	if ( learner.neural_network_round % 5 != 0 )
	{
		

		learner.evalutation_times.push( ( learner.evaluation_end_time - learner.evaluation_start_time ) / 1000 );
		
		learner.neural_network_round += 1;
		
		learner.evaluation_start_time = new Date( ).getTime( );
		
		learner.evaluation_end_time   = 0;	
		
		
	}
	else 
	{
		
		var time_average = get_average( learner.evalutation_times );
		
		learner.evaluation_time_averages.push( time_average );
		
		learner.evalutation_times = [ ];
		
		learner.evaluation_start_time = new Date( ).getTime( );
		
		learner.evaluation_end_time   = 0;
		
		if ( ( learner.current_neural_net_in_evalutation + 1 ) % 10 == 0 ) { console.log( learner.evaluation_time_averages ); stop_tournament = true; return; }
		
		learner.current_neural_net_in_evalutation += 1;
		
		learner.neural_net.put_weights( learner.neural_network_weights[ learner.current_neural_net_in_evalutation ] );		
		
		learner.neural_network_round = 1;
		
	}		
	
	learner.evaluate_current_neural_network = false;
	
	reset( );
	
}

var ball_magnitude_reduction_threshold = 100;
var ball_magnitude_reduce_by_percentage = .5;

function collision_handler( colliding_objects )
{
	
	learner.evaluate_current_neural_network = false;
	
	for ( var i = 0; i < colliding_objects.length; ++i )
	{
		
		// Ball collisions
		
		if ( colliding_objects[ i ][ 0 ].id == "ball" && colliding_objects[ i ][ 1 ].id == "paddle" || ( colliding_objects[ i ][ 0 ].id == "paddle" && colliding_objects[ i ][ 1 ].id == "ball" ) )
		{
			
			ball.set_magnitude( ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * ball_magnitude_reduce_by_percentage ) ) > ball_magnitude_reduction_threshold ? ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * .1 ) ) : 0 ); 
			
			if ( ball.get_magnitude( ) == 0 )
			{
				
				if ( learner.evaluation_start_time != 0 )
				{
					
					learner.evaluation_end_time = new Date( ).getTime( );
					
				}
				
				learner.evaluate_current_neural_network = true;
				
			}
			
			// Wind the ball's position back, going along the direction opposite of the angle it was traveling along when it collided with 
			// the paddle until it no longer collides with the paddle.
			// This is easier to calculate than finding the intersection of a line along the direction of the ball's vector with that of
			// the paddle's top, right, bottom, and left boundary lines.

			var reverse_angle = ball.mod_degrees( ( ball.get_angle( ) + 180 ) );			
			var dx =  5 * Math.cos( ball.degrees_to_radians( reverse_angle ) );			
			var dy = -5 * Math.sin( ball.degrees_to_radians( reverse_angle ) ); // Negative one because of the mirrored coordinate system. 			
			while ( physics_engine.rectangle_intersection( paddle.dynamic_object, ball.dynamic_object ) )
			{
				
				ball.dynamic_object.move_center( dx, dy );
				
			}
			
			// There are two cases:
			// 	1. The ball hits the paddle from the top or bottom.
			//	2. The ball hits the paddle from either the left or right.
			
			if ( ( ball.dynamic_object.get_top( ) > paddle.dynamic_object.get_bottom( ) ) || ( ball.dynamic_object.get_bottom( ) < paddle.dynamic_object.get_top( ) ) )
			{
				
				// Top or bottom side case.
				
				// Physics_Object.set_angle expects an angle as if y+ was going UP the screen.
				// So say the ball hits the top wall at 35 degrees. The angle of incidence would be 35 degrees and so the ball should be reflected back
				// at -35 degrees or -35 % 360 = 325  which we set.
				// -1 * 35 = -35 mod 360 = 325
				// |_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_|
				//                       .
				//                         )
				// .   )                                       .
				// ---------------------------------------------
				
				var reflection_angle = ball.mod_degrees( -1 * ball.get_angle( ) );			
				ball.set_angle( reflection_angle );
				
			}
			else
			{
			
				// Left or right side case.
				
				// Physics_Object.set_angle expects an angle as if y+ was going UP the screen.
				// So say the ball hits the paddle at 170 degrees. The angle of incidence would be 10 degrees and so the ball should be reflected back
				// at 10 degrees which we set.
				// -1 * ( 170 - 180 ) = 10
				// |/|
				// |/|
				// |/|
				// |/|                 .
				// |/|.________________)___
				// |/|                (.
				// |/|
				// |/|
				
				
				var reflection_angle = -1 * ( ball.get_angle( ) - 180.0);
				ball.set_angle( reflection_angle );
				
			}
			
		}		
		else if ( colliding_objects[ i ][ 0 ].id == "ball" && colliding_objects[ i ][ 1 ].id == "top_wall" || ( colliding_objects[ i ][ 0 ].id == "top_wall" && colliding_objects[ i ][ 1 ].id == "ball" ) )
		{
			
			ball.set_magnitude( ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * ball_magnitude_reduce_by_percentage ) ) > ball_magnitude_reduction_threshold ? ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * .1 ) ) : 0 ); 
			
			if ( ball.get_magnitude( ) == 0 )
			{
				
				if ( learner.evaluation_start_time != 0 )
				{
					
					learner.evaluation_end_time = new Date( ).getTime( );
					
				}
				
				learner.evaluate_current_neural_network = true;
				
			}
			
			
			ball.dynamic_object.move_center( 0, ( -1 * ball.dynamic_object.get_top( ) ) + 1 );
			
			// Physics_Object.set_angle expects an angle as if y+ was going UP the screen.
			// So say the ball hits the top wall at 35 degrees. The angle of incidence would be 35 degrees and so the ball should be reflected back
			// at -35 degrees or -35 % 360 = 325  which we set.
			// -1 * 35 = -35 mod 360 = 325
			// |_||_||_||_||_||_||_||_||_||_||_||_||_||_||_||_|
			//                       .
			//                         )
			// .   )                                       .
			// ---------------------------------------------
		
			
			var reflection_angle = ball.mod_degrees( -1 * ball.get_angle( ) );			
			ball.set_angle( reflection_angle );
			
		}
		else if ( colliding_objects[ i ][ 0 ].id == "ball" && colliding_objects[ i ][ 1 ].id == "right_wall" || ( colliding_objects[ i ][ 0 ].id == "right_wall" && colliding_objects[ i ][ 1 ].id == "ball" ) )
		{
			
			ball.set_magnitude( ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * ball_magnitude_reduce_by_percentage ) ) > ball_magnitude_reduction_threshold ? ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * .1 ) ) : 0 ); 
			
			if ( ball.get_magnitude( ) == 0 )
			{
				
				if ( learner.evaluation_start_time != 0 )
				{
					
					learner.evaluation_end_time = new Date( ).getTime( );
					
				}
				
				learner.evaluate_current_neural_network = true;
				
			}			
			
			ball.dynamic_object.move_center( ( -1 * ( ball.dynamic_object.get_right( ) - window.innerWidth ) ) -1, 0 ); 
			
			var reflection_angle = -1 * ( ball.get_angle( ) - 180.0);
			ball.set_angle( reflection_angle );
			
		}
		else if ( colliding_objects[ i ][ 0 ].id == "ball" && colliding_objects[ i ][ 1 ].id == "bottom_wall" || ( colliding_objects[ i ][ 0 ].id == "bottom_wall" && colliding_objects[ i ][ 1 ].id == "ball" ) )
		{
			
			ball.set_magnitude( ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * ball_magnitude_reduce_by_percentage) ) > ball_magnitude_reduction_threshold ? ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * .1 ) ) : 0 ); 
			
			if ( ball.get_magnitude( ) == 0 )
			{
				
				if ( learner.evaluation_start_time != 0 )
				{
					
					learner.evaluation_end_time = new Date( ).getTime( );
					
				}
				
				learner.evaluate_current_neural_network = true;
				
			}			
			
			ball.dynamic_object.move_center( 0, ( -1 * ( ball.dynamic_object.get_bottom( ) - window.innerHeight ) ) -1 );
			
			var reflection_angle = ball.mod_degrees( -1 * ball.get_angle( ) );			
			ball.set_angle( reflection_angle );
			
		}
		else if ( colliding_objects[ i ][ 0 ].id == "ball" && colliding_objects[ i ][ 1 ].id == "left_wall" || ( colliding_objects[ i ][ 0 ].id == "left_wall" && colliding_objects[ i ][ 1 ].id == "ball" ) )
		{
			
			ball.set_magnitude( ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * ball_magnitude_reduce_by_percentage ) ) > ball_magnitude_reduction_threshold ? ( ball.get_magnitude( ) - ( ball.get_magnitude( ) * .1 ) ) : 0 ); 

			if ( learner.evaluation_start_time != 0 )
			{
				
				learner.evaluation_end_time = new Date( ).getTime( );
				
			}
			
			learner.evaluate_current_neural_network = true;
			
			ball.dynamic_object.move_center( ( -1 * ( ball.dynamic_object.get_left( ) ) ) + 1, 0 ); 
			
			var reflection_angle = -1 * ( ball.get_angle( ) - 180.0);
			ball.set_angle( reflection_angle );
			
		}
		
		// Paddle collisions.
		
		if ( colliding_objects[ i ][ 0 ].id == "paddle" && colliding_objects[ i ][ 1 ].id == "top_wall" || ( colliding_objects[ i ][ 0 ].id == "top_wall" && colliding_objects[ i ][ 1 ].id == "paddle" ) )
		{
			
			paddle.dynamic_object.move_center( 0, ( -1 * paddle.dynamic_object.get_top( ) ) + 1 );
			
		}
		else if ( colliding_objects[ i ][ 0 ].id == "paddle" && colliding_objects[ i ][ 1 ].id == "bottom_wall" || ( colliding_objects[ i ][ 0 ].id == "bottom_wall" && colliding_objects[ i ][ 1 ].id == "paddle" ) )
		{
			
			paddle.dynamic_object.move_center( 0, ( -1 * ( paddle.dynamic_object.get_bottom( ) - window.innerHeight ) ) -1 );
			
		}			
		
	}
	
}

